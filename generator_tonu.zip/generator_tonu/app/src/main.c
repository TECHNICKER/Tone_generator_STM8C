#include "stm8s.h"

/*
C
C#
D
D#
E
F
F#
G
G#
A
A#
H

*/

// void tone(ARR)
// {

// }

void main(void)
{
    EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOB, EXTI_SENSITIVITY_FALL_ONLY);
    ITC_SetSoftwarePriority(ITC_IRQ_PORTB, ITC_PRIORITYLEVEL_0);

    enableInterrupts();

    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1); // FREQ MCU 16MHz
    GPIO_Init(GPIOB, GPIO_PIN_0, GPIO_MODE_OUT_PP_LOW_SLOW);

    TIM4_TimeBaseInit(TIM4_PRESCALER_128, 142);
    TIM4_Cmd(ENABLE);

    while (1)
    {
        if(TIM4_GetFlagStatus(TIM4_FLAG_UPDATE) == SET)
        {
            TIM4_ClearFlag(TIM4_FLAG_UPDATE);
            GPIO_WriteReverse(GPIOB, GPIO_PIN_0);
        }
    }
}

